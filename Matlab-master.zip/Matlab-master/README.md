# Matlab application

Each folder is an independent application, and the corresponding instructions are detailed in the README.md file under each folder.