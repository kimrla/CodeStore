function drawsumheat(k,N,lambda)
%% ����ͼ
heatlambda=zeros(length(lambda)/2,N);
normheatlambda=heatlambda;
heatlambda(:,1:2)=kron(reshape(lambda(1:(k+1)*2),[],2),ones(2^(N-2),1));
for n=3:N
    heatlambda(:,n)=kron(lambda((k+1)*2^(n-2)+1:(k+1)*2^(n-1)),ones(2^(N-n),1));
end
heatlambda=abs(heatlambda);
normheatlambda(:,1:2)=1;
for n=3:N  %��ÿһ���������ϵ���ֱ�ȡ����ֵ���һ��
    for j=1:k+1
        normheatlambda(1+(j-1)*2^(N-2):j*2^(N-2),n)= ...,
            heatlambda(1+(j-1)*2^(N-2):j*2^(N-2),n);
    end
end
heat=zeros();
figure
for j=1:k+1
ylable=[0 1];
xlable=1:N;
subplot(k+1,1,j),imagesc(xlable,ylable,normheatlambda(1+(j-1)*2^(N-2):j*2^(N-2),:))
heat=heat+normheatlambda(1+(j-1)*2^(N-2):j*2^(N-2),:);
set(gca,'xtick',1:N)
end
for n=1:N
    heat(:,n)=heat(:,n)/max(heat(:,n));
end
figure
ylable=[0 1];
xlable=1:N;
imagesc(xlable,ylable,heat)
set(gca,'xtick',1:N)
end

