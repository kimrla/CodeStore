3D-Surface-Reconstruction
=========================
An implementation of a particle swarm approach to 3D surface fitting algorithms.

Current list of algorithms availible:
PSO-NURBS

UOIT Computer Vision and Games Final Project
by Syed Raazi Rizvi
