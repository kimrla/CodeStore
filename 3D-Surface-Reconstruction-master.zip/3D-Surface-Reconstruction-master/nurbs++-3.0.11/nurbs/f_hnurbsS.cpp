#include "hnurbsS.cpp"

namespace PLib {

#ifdef NO_IMPLICIT_TEMPLATES
  template class HNurbsSurface<float,3> ;
#endif

}
