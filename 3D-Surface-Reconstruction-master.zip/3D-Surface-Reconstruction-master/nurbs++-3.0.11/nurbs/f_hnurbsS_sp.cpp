#include "hnurbsS_sp.cpp"

namespace PLib {

#ifdef NO_IMPLICIT_TEMPLATES
  template class HNurbsSurfaceSP<float,3> ;
#endif 

}
