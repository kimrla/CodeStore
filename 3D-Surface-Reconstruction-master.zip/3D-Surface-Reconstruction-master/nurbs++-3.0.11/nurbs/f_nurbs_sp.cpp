#include "nurbs_sp.cpp"

namespace PLib {

#ifdef NO_IMPLICIT_TEMPLATES

  template class NurbsCurveSP<float,3> ;
  template class NurbsCurveSP<float,2> ;

#endif 

}

