#include "nurbsS_sp.cpp"




namespace PLib {

#ifdef NO_IMPLICIT_TEMPLATES

  template class NurbsSurfaceSP<double,3> ;

#endif 

}
