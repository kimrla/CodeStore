# Matlab_OOP_CAGD
This is an OOD framework in Matlab, designed for development of CAGD (Computer Aided Geometric Design) applications. Currently it includes several processing and plotting functions using B-Splines and NURBS for 1D, 2D and 3D topologies.
